//------------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------

namespace System.Web.Services.Configuration
{
    public enum PriorityGroup
    {
        High = 0,
        Low = 1
    }
}



