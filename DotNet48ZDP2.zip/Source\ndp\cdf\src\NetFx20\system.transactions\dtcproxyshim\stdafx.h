//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


// Windows Header Files:
#include <windows.h>

// 
#include <winerror.h>
#include <txdtc.h>
#include <txcoord.h>
#include <transact.h>
#include <xolehlp.h>
#include <ocidl.h>
